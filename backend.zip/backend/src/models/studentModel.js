module.exports = (sequelize, Sequelize) => {
    const Student = sequelize.define("students", {
        name: {
            type: Sequelize.STRING,
            allowNull: false
        },
        gender: {
            type: Sequelize.ENUM('Male', 'Female'),
            allowNull: false
        },
        address: {
            type: Sequelize.TEXT,
            allowNull: true
        },
        fatherName: {
            type: Sequelize.STRING,
            allowNull: true
        },
        motherName: {
            type: Sequelize.STRING,
            allowNull: true
        },
        birthPlace: {
            type: Sequelize.STRING,
            allowNull: true
        },
        birthDate: {
            type: Sequelize.DATEONLY,
            allowNull: true
        },
        phoneNumber: {
            type: Sequelize.STRING,
            allowNull: false
        },
        email: {
            type: Sequelize.STRING,
            allowNull: false,
            validate: {
                isEmail: true
            }
        },
        course: {
            type: Sequelize.STRING,
            allowNull: true
        },
        programId: {
            type: Sequelize.INTEGER,
            allowNull: true,
            references: {
                model: 'programs',
                key: 'id'
            }
        },
        userId: {
            type: Sequelize.INTEGER,
            allowNull: true,
            references: {
                model: "users",
                key: "id",
            },
        },
        status: {
            type: Sequelize.ENUM('Waiting List', 'Active', 'Non Active', 'Postponed'),
            allowNull: false,
            defaultValue: 'Waiting List'
        }
    });

    return Student;
};
